﻿Imports FakeItEasy

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, e As Integer
        a = 0
        b = 0
        e = 0
        If IsNumeric(TextBox1.Text) Then
            a = Int(TextBox1.Text)
        Else
            e = 1
        End If
        If IsNumeric(TextBox2.Text) Then
            b = Int(TextBox2.Text)
        Else
            e += 2
        End If
        Label4.Text = (a + b)
        If e = 1 Then
            Label5.Text = "Invalid First Number"
        ElseIf e = 2 Then
            Label5.Text = "Invalid Second Number"
        ElseIf e = 3 Then
            Label5.Text = "Invalid Numbers"
        End If

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub
End Class
